<?php 
use EFrame\Helper\T;
?>
<!DOCTYPE HTML>
<html>
<head>
</head>
<body>
<style>
section{
	margin-top:1em;
}
</style>

<?php 
echo  $this->contents();
?>

</body>
</html>