<?php
return $modelStyle = [
    //页面名称
    'index'=>[
        //页面小部件名称 => '小部件js'  （如果当前小部件的样式没有被用户修改过，则为空字符，系统需要加载该小部件的默认样式）
        'header_0'=>'jsonstring',
        //页面小部件名称
        'headerBanner_0' => 'jsonstring',
    ],
    //页面名称
    'news' => [
        //页面小部件名称 => '小部件js'  （如果当前小部件的样式没有被用户修改过，则为空字符，系统需要加载该小部件的默认样式）
        'header_2' => 'jsonstring',
        //页面小部件名称
        'navication_0' => 'jsonstring',
        'newsList_0' => 'jsonstring',
        'footer_0'  => 'jsonstring'
    ],
];