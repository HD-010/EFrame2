<?php 
use EFrame\Helper\T;
?>
<style>
    .recommondNews_0{
        border:1px solid;
    }
</style>
<section class="recommondNews_0" data-module_name="recommondNews_0">
这是ArticalList.php
    <?php
        T::print_pre($data);
    ?>
</section>
