<?php 
use EFrame\Helper\T;
?>
<style>
.footer_0{
    border:1px solid;
}
</style>
<section class="footer_0" data-module_name="footer_0">
这是footer_0.php
    <?php
    T::print_pre($data);
    ?>

</section>
