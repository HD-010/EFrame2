<?php 
use EFrame\Helper\T;
?>

<style>
    .hearderBanner_0{
        border:1px solid;
    }

</style>

<section class="hearderBanner_0" data-module_name="hearderBanner_0">
这是headerBanner_0.php
    <?php
    T::print_pre($data);
    ?>

</section>
