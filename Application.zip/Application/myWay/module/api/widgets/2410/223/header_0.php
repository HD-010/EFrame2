<?php 
use EFrame\Helper\T;
?>

<style>
    .header_0{
        border:1px solid;
    }

</style>
<section class="header_0" data-module_name="header_0">
这是header_0.php
    <?php
    T::print_pre($data);
    ?>

</section>

