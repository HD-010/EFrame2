<?php 
use EFrame\Helper\T;
?>

<style>
    .navication_0{
        border:1px solid;
    }
</style>

<section class="navication_0" data-module_name="navication_0">
这是navication_0.php
    <?php
    //T::print_pre($data);
    ?>
</section>
