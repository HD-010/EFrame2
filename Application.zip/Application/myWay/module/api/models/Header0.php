<?php
/**
 * Created by PhpStorm.
 * User: yx010
 * Date: 2018/8/12
 * Time: 22:05
 */
namespace myWay\module\api\models;

use App;
use EFrame\Helper\T;

class Header0
{
    public function get(){
        return ['Header0'];
    }
}