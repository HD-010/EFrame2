<?php
/**
 * Created by PhpStorm.
 * User: yx010
 * Date: 2018/8/12
 * Time: 22:09
 */
namespace myWay\module\api\models;

use App;
use EFrame\Helper\T;

class HeaderBanner1
{
    public function get(){
        return ['HeaderBanner1'];
    }
}