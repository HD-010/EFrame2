<?php
return [
    //默认路由
    'defaultRout' => '/api/Index/index',
];