<?php
//print_r($this->data);
echo "ok";

echo $this->renderWidget('testwidget','52');