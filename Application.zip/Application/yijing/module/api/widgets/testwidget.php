<?php
echo "this is test widget";
echo $data;